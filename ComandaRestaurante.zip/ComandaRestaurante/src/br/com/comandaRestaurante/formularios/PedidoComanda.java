package br.com.comandaRestaurante.formularios;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;

/*
 * Abaixo importamos as classes 
 * import java.sql.*;
import br.com.infox.dal.ModuloConexao;
para ajudar a conex�o com o banco de dados 
 * */
import java.sql.*;
import java.text.DecimalFormat;

import br.com.comandaRestaurante.conex.*;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import java.awt.ScrollPane;
import java.awt.Scrollbar;

public class PedidoComanda extends JInternalFrame {

	/* Objetos e vari�veis para trabalhar com o sql */
	Connection conex = null; // Esse faz a conex�o
	PreparedStatement pst = null;// Esse permite fazer altera��es no banco de dados
	ResultSet rs = null;// Esse traz os resultados do sql

	/*********** M�todos **********/

	private void pesquisarPedido() {
		String pesquisaPedido = "select * from tb_pedidos where idPedido = ?";

		// Tratamento de Exce��es
		try {
			// A linha abaixo prepara "digita" o comando sql
			pst = conex.prepareStatement(pesquisaPedido);
			// A linha substitui o par�metro ? pelo o que foi digitado na caixa de texto
			// txtIdF
			pst.setString(1, txtIdPedido.getText());
			// A linha abaixo executa o comando
			rs = pst.executeQuery();
			// Estrutura que verifica se existe um funcion�rio
			if (rs.next()) {
				// Preecher os campos do formul�rio
				txtNumeroMesa.setText(rs.getString(2));
				txtNomeProdutoPedido.setText(rs.getString(3));
				txtQuatidadePedido.setText(rs.getString(4));
				txtValorPedido.setText(rs.getString(5));
				txtValorConta.setText(rs.getString(6));
				txtJustifExclusao.setText(rs.getString(7));
				txtJustifTransf.setText(rs.getString(8));
				txtObservacaoPedido.setText(rs.getString(9));
				txtIdFunc.setText(rs.getString(10));
				txtIdCli.setText(rs.getString(11));

			} else {
				// Mensagem se n�o existir um pedido cadastrado
				JOptionPane.showMessageDialog(null, "Pedido n�o encontrado");
				limpar();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para adicionar os pedidos */

	private void adicionarPedido() {
		String adicionaPedido = "insert into tb_pedidos(idPedido,numeroMesa, nomeProdutoPedido, quatidadePedido, valorPedido, valorConta, justifExclusao, justifTransf, observacaoPedido, idFunc, idCli) values (?,?,?,?,?,?,?,?,?,?,?)";
		try {
			pst = conex.prepareStatement(adicionaPedido);

			pst.setString(1, txtIdPedido.getText());
			pst.setString(2, txtNumeroMesa.getText());
			pst.setString(3, txtNomeProdutoPedido.getText());
			pst.setString(4, txtQuatidadePedido.getText());
			pst.setString(5, txtValorPedido.getText());
			pst.setString(6, txtValorConta.getText());
			pst.setString(7, txtJustifExclusao.getText());
			pst.setString(8, txtJustifTransf.getText());
			pst.setString(9, txtObservacaoPedido.getText());
			pst.setString(10, txtIdFunc.getText());
			pst.setString(11, txtIdCli.getText());

			// Valida��o dos campos obrigat�rios

			if ((txtNumeroMesa.getText().isEmpty()) || (txtNomeProdutoPedido.getText().isEmpty())
					|| (txtQuatidadePedido.getText().isEmpty()) || (txtValorPedido.getText().isEmpty())
					|| (txtValorConta.getText().isEmpty()) || (txtIdFunc.getText().isEmpty())) {
				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");

			} else {
				// CRIANDO UMA V�RIAV�L PARA EXECUTAR A QUERY E EXIBIR UMA MENSAGEM AO USU�RIO
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Pedido cadastrado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao cadastrar Pedido");
				}

			}

		} catch (Exception e) {

			System.out.println(e);
		}
	}

	/* M�todo para alterar Pedidos */

	private void alterarPedido() {
		String alteraPedido = "update tb_pedidos set numeroMesa = ?,nomeProdutoPedido = ?,quatidadePedido = ?,valorPedido = ?,valorConta = ?,justifExclusao = ?,justifTransf = ?,observacaoPedido = ?,idFunc = ?,idCli  = ? where idPedido = ?";
		try {
			pst = conex.prepareStatement(alteraPedido);

			pst.setString(1, txtNumeroMesa.getText());
			pst.setString(2, txtNomeProdutoPedido.getText());
			pst.setString(3, txtQuatidadePedido.getText());
			pst.setString(4, txtValorPedido.getText());
			pst.setString(5, txtValorConta.getText());
			pst.setString(6, txtJustifExclusao.getText());
			pst.setString(7, txtJustifTransf.getText());
			pst.setString(8, txtObservacaoPedido.getText());
			pst.setString(9, txtIdFunc.getText());
			pst.setString(10, txtIdCli.getText());
			pst.setString(11, txtIdPedido.getText());

			// Valida��o dos campos obrigat�rios
			if ((txtNumeroMesa.getText().isEmpty()) || (txtNomeProdutoPedido.getText().isEmpty())
					|| (txtQuatidadePedido.getText().isEmpty()) || (txtValorPedido.getText().isEmpty())
					|| (txtValorConta.getText().isEmpty()) || (txtIdFunc.getText().isEmpty())) {
				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");
			} else {
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Pedido alterado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao alterar o  Pedido");
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todos para remover um pedido */

	private void removerPedido() {
		String removePedido = "delete from tb_pedidos where idPedido = ?";
		try {
			pst = conex.prepareStatement(removePedido);
			pst.setString(1, txtIdPedido.getText());
			// Antes de remover o pedido confirmar
			// A vari�vel abaixo recebe a op��o da caixa de di�logo
			int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover este Pedido?", "Aten��o",
					JOptionPane.YES_NO_OPTION);
			if (confirma == JOptionPane.YES_NO_OPTION) {
				int removido = pst.executeUpdate();
				if (removido == 1) {
					JOptionPane.showMessageDialog(null, "Pedido removido com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "N�o foi poss�vel remover Pedido");
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para limpar os campos */

	private void limpar() {
		txtIdPedido.setText(null);
		txtNumeroMesa.setText(null);
		txtNomeProdutoPedido.setText(null);
		txtQuatidadePedido.setText(null);
		txtValorPedido.setText(null);
		txtValorConta.setText(null);
		txtJustifExclusao.setText(null);
		txtJustifTransf.setText(null);
		txtObservacaoPedido.setText(null);
		txtIdFunc.setText(null);
		txtIdCli.setText(null);

	}

	private JTextField txtIdPedido;
	private JTextField txtNumeroMesa;
	private JTextField txtNomeProdutoPedido;
	private JTextField txtQuatidadePedido;
	private JTextField txtValorPedido;
	private JTextField txtValorConta;
	private JTextField txtJustifExclusao;
	private JTextField txtJustifTransf;
	private JTextField txtObservacaoPedido;
	private JTextField txtIdFunc;
	private JTextField txtFuncPesquisaPed;
	private JTable table;
	private JTextField txtIdCli;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PedidoComanda frame = new PedidoComanda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PedidoComanda() {
		setIconifiable(true);
		setClosable(true);
		setResizable(true);
		setTitle("Pedido");
		setBounds(0, 0, 974, 727);
		getContentPane().setLayout(null);

		JLabel lblIdp = new JLabel("ID PEDIDO");
		lblIdp.setBounds(10, 11, 71, 14);
		getContentPane().add(lblIdp);

		JLabel lblNumeromesa = new JLabel("N\u00BA MESA");
		lblNumeromesa.setBounds(10, 36, 71, 14);
		getContentPane().add(lblNumeromesa);

		JLabel lblNomepedido = new JLabel("NOME PEDIDO");
		lblNomepedido.setBounds(10, 61, 105, 14);
		getContentPane().add(lblNomepedido);

		JLabel lblQuatidadepedido = new JLabel("QUANTI.");
		lblQuatidadepedido.setBounds(10, 90, 71, 14);
		getContentPane().add(lblQuatidadepedido);

		JLabel lblValorpedido = new JLabel("VALOR UN.");
		lblValorpedido.setBounds(265, 11, 87, 14);
		getContentPane().add(lblValorpedido);

		JLabel lblValorconta = new JLabel("VALOR CONTA");
		lblValorconta.setBounds(265, 36, 87, 14);
		getContentPane().add(lblValorconta);

		JLabel lblJustifexclusao = new JLabel("JUSTIF. EXCLUS\u00C3O");
		lblJustifexclusao.setBounds(265, 61, 87, 14);
		getContentPane().add(lblJustifexclusao);

		JLabel lblJustiftransfer = new JLabel("JUSTIFI. TRANSFER\u00CANCIA");
		lblJustiftransfer.setBounds(265, 86, 142, 14);
		getContentPane().add(lblJustiftransfer);

		JLabel lblObservacaopedido = new JLabel("OBS. PEDIDO");
		lblObservacaopedido.setBounds(265, 115, 87, 14);
		getContentPane().add(lblObservacaopedido);

		JLabel lblIdfunc = new JLabel("ID FUNCION\u00C1RIO");
		lblIdfunc.setBounds(595, 11, 70, 14);
		getContentPane().add(lblIdfunc);

		JLabel lblIdcli = new JLabel("ID CLIENTE");
		lblIdcli.setBounds(595, 36, 100, 14);
		getContentPane().add(lblIdcli);

		JLabel label_12 = new JLabel("* Campos obrigat\u00F3rio");
		label_12.setBounds(10, 148, 130, 14);
		getContentPane().add(label_12);

		txtIdPedido = new JTextField();
		txtIdPedido.setColumns(10);
		txtIdPedido.setBounds(91, 5, 164, 20);
		getContentPane().add(txtIdPedido);

		txtNumeroMesa = new JTextField();
		txtNumeroMesa.setColumns(10);
		txtNumeroMesa.setBounds(91, 30, 164, 20);
		getContentPane().add(txtNumeroMesa);

		txtNomeProdutoPedido = new JTextField();
		txtNomeProdutoPedido.setColumns(10);
		txtNomeProdutoPedido.setBounds(91, 55, 164, 20);
		getContentPane().add(txtNomeProdutoPedido);

		txtQuatidadePedido = new JTextField();
		txtQuatidadePedido.setColumns(10);
		txtQuatidadePedido.setBounds(91, 84, 164, 20);
		getContentPane().add(txtQuatidadePedido);

		txtValorPedido = new JTextField();
		txtValorPedido.setColumns(10);
		txtValorPedido.setBounds(404, 5, 130, 20);
		getContentPane().add(txtValorPedido);

		txtValorConta = new JTextField();
		txtValorConta.setColumns(10);
		txtValorConta.setBounds(404, 30, 130, 20);
		getContentPane().add(txtValorConta);

		txtJustifExclusao = new JTextField();
		txtJustifExclusao.setColumns(10);
		txtJustifExclusao.setBounds(404, 55, 130, 20);
		getContentPane().add(txtJustifExclusao);

		txtJustifTransf = new JTextField();
		txtJustifTransf.setColumns(10);
		txtJustifTransf.setBounds(404, 80, 130, 20);
		getContentPane().add(txtJustifTransf);

		txtObservacaoPedido = new JTextField();
		txtObservacaoPedido.setColumns(10);
		txtObservacaoPedido.setBounds(404, 109, 130, 20);
		getContentPane().add(txtObservacaoPedido);

		txtIdFunc = new JTextField();
		txtIdFunc.setColumns(10);
		txtIdFunc.setBounds(691, 5, 130, 20);
		getContentPane().add(txtIdFunc);

		txtIdCli = new JTextField();
		txtIdCli.setColumns(10);
		txtIdCli.setBounds(691, 33, 130, 20);
		getContentPane().add(txtIdCli);

		txtFuncPesquisaPed = new JTextField();
		txtFuncPesquisaPed.setColumns(10);
		txtFuncPesquisaPed.setBounds(224, 186, 183, 20);
		getContentPane().add(txtFuncPesquisaPed);

		JLabel label_13 = new JLabel("");
		label_13.setIcon(
				new ImageIcon(PedidoComanda.class.getResource("/br/com/comandaRestaurante/icones/pesquisar.png")));
		label_13.setBounds(417, 167, 46, 56);
		getContentPane().add(label_13);

		JButton btnExcluir = new JButton("");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removerPedido();
			}
		});
		btnExcluir.setIcon(new ImageIcon(PedidoComanda.class.getResource("/br/com/comandaRestaurante/icones/delete.png")));
		btnExcluir.setBounds(494, 334, 89, 82);
		getContentPane().add(btnExcluir);

		JButton btnAlterar = new JButton("");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alterarPedido();
			}
		});
		btnAlterar.setIcon(
				new ImageIcon(PedidoComanda.class.getResource("/br/com/comandaRestaurante/icones/update.png")));
		btnAlterar.setBounds(364, 334, 89, 82);
		getContentPane().add(btnAlterar);

		JButton btnPesquisar = new JButton("");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pesquisarPedido();
			}
		});
		btnPesquisar.setIcon(new ImageIcon(PedidoComanda.class.getResource("/br/com/comandaRestaurante/icones/read.png")));
		btnPesquisar.setBounds(229, 334, 89, 82);
		getContentPane().add(btnPesquisar);

		JButton btnAdicionar = new JButton("");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarPedido();
			}
		});
		btnAdicionar.setIcon(
				new ImageIcon(PedidoComanda.class.getResource("/br/com/comandaRestaurante/icones/create.png")));
		btnAdicionar.setBounds(91, 334, 89, 82);
		getContentPane().add(btnAdicionar);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 217, 714, 106);
		getContentPane().add(scrollPane);

		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"ID PEDIDO", "N\u00BA MESA", "NOME PEDIDO", "QUANTI.", "VALOR UN.", "VALOR CONTA", "JUSTIFI. EXCLUS\u00C3O", "JUSTIFI. EXCLUS\u00C3O", "JUSTIFI. TRANSFER\u00CANCIA", "OBS. PEDIDO", "ID FUNCION\u00C1RIO", "ID CLIENTE"
			}
		));
		scrollPane.setViewportView(table);

		// Importante !!! -> Usar o m�todo conector() do M�dulo de Conex�o

		conex = ConexaoBancoDados.conect();
	}
}
