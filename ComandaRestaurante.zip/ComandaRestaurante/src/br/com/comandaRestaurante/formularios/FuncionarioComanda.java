package br.com.comandaRestaurante.formularios;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JSplitPane;
import javax.swing.ImageIcon;
/*
 * Abaixo importamos as classes 
 * import java.sql.*;
import br.com.infox.dal.ModuloConexao;
para ajudar a conex�o com o banco de dados 
 * */
import java.sql.*;
import br.com.comandaRestaurante.conex.*;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
//rs2xml.jar (framework para facilitar trabalho com tabelas)
import net.proteanit.sql.DbUtils;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class FuncionarioComanda extends JInternalFrame {
	/* Objetos e vari�veis para trabalhar com o sql */
	Connection conex = null; // Esse faz a conex�o
	PreparedStatement pst = null;// Esse permite fazer altera��es no banco de dados
	ResultSet rs = null;// Esse traz os resultados do sql

	/*********** M�todos **********/

	// Pesquisar Funcion�rio
	private void pesquisarFuncionario() {
		String pesquisaFuncionario = "select * from tb_funcionarios where idFunc = ?";

		// Tratamento de Exce��es
		try {
			// A linha abaixo prepara "digita" o comando sql
			pst = conex.prepareStatement(pesquisaFuncionario);
			// A linha substitui o par�metro ? pelo o que foi digitado na caixa de texto
			// txtidFunc
			pst.setString(1, txtIdFunc.getText());
			// A linha abaixo executa o comando
			rs = pst.executeQuery();
			// Estrutura que verifica se existe um funcion�rio
			if (rs.next()) {
				// Preecher os campos do formul�rio

				txtCargoFunc.setText(rs.getString(2));
				txtCpfFunc.setText(rs.getString(3));
				txtNomeFunc.setText(rs.getString(4));
				txtDataNascimento.setText(rs.getString(5));
				txtFone1Func.setText(rs.getString(6));
				txtFone2Func.setText(rs.getString(7));
				txtCepFunc.setText(rs.getString(8));
				txtCidadeFunc.setText(rs.getString(9));
				txtBairroFunc.setText(rs.getString(10));
				txtRuaFunc.setText(rs.getString(11));
				txtEstado.setText(rs.getString(12));
				txtComplementoEndfunc.setText(rs.getString(13));
				txtLoginFunc.setText(rs.getString(14));
				txtSenhaFunc.setText(rs.getString(15));
				txtEmailFunc.setText(rs.getString(16));

			} else {
				// Mensagem se n�o existir um funcion�rio cadastrado
				JOptionPane.showMessageDialog(null, "Funcion�rio n�o encontrado");
				limpar();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para adicionar os funcion�rios */

	private void adicionarFuncionario() {
		String adicionaFuncionario = "insert into tb_funcionarios(idFunc,cargoFunc,cpFfunc,nomeFunc,dataNascimento,fone1Func,fone2Func,cepFunc,cidadeFunc,bairroFunc,ruaFunc,estado,complementoEndfunc,loginFunc, senhaFunc,emailFunc) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			pst = conex.prepareStatement(adicionaFuncionario);
			pst.setString(1, txtIdFunc.getText());
			pst.setString(2, txtCargoFunc.getText());
			pst.setString(3, txtCpfFunc.getText());
			pst.setString(4, txtNomeFunc.getText());
			pst.setString(5, txtDataNascimento.getText());
			pst.setString(6, txtFone1Func.getText());
			pst.setString(7, txtFone2Func.getText());
			pst.setString(8, txtCepFunc.getText());
			pst.setString(9, txtCidadeFunc.getText());
			pst.setString(10, txtBairroFunc.getText());
			pst.setString(11, txtRuaFunc.getText());
			pst.setString(12, txtEstado.getText());
			pst.setString(13, txtComplementoEndfunc.getText());
			pst.setString(14, txtLoginFunc.getText());
			pst.setString(15, txtSenhaFunc.getText());
			pst.setString(16, txtEmailFunc.getText());

			// Valida��o dos campos obrigat�rios
			if ((txtCpfFunc.getText().isEmpty()) || (txtNomeFunc.getText().isEmpty())
					|| (txtLoginFunc.getText().isEmpty()) || (txtSenhaFunc.getText().isEmpty())
					|| (txtEmailFunc.getText().isEmpty())) {
				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");

			} else {
				// CRIANDO UMA V�RIAV�L PARA EXECUTAR A QUERY E EXIBIR UMA MENSAGEM AO USU�RIO
				int adicionado = pst.executeUpdate();

				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Funcion�rio cadastrado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao cadastrar Funcion�rio");
				}

			}

		} catch (Exception e) {

			System.out.println(e);
		}
	}

	/* M�todo para alterar funcion�rios */

	private void alterarFuncionario() {
		String alteraFuncionario = "update tb_funcionarios set cargoFunc = ?,cpFfunc = ?,nomeFunc = ?,dataNascimento = ?,fone1Func = ?,fone2Func = ?,cepFunc = ?,cidadeFunc = ?,bairroFunc = ?,ruaFunc = ?,estado = ?,complementoEndfunc = ?,loginFunc = ?, senhaFunc = ?,emailFunc = ? where idFunc = ?";
		try {
			pst = conex.prepareStatement(alteraFuncionario);

			pst.setString(1, txtCargoFunc.getText());
			pst.setString(2, txtCpfFunc.getText());
			pst.setString(3, txtNomeFunc.getText());
			pst.setString(4, txtDataNascimento.getText());
			pst.setString(5, txtFone1Func.getText());
			pst.setString(6, txtFone2Func.getText());
			pst.setString(7, txtCepFunc.getText());
			pst.setString(8, txtCidadeFunc.getText());
			pst.setString(9, txtBairroFunc.getText());
			pst.setString(10, txtRuaFunc.getText());
			pst.setString(11, txtEstado.getText());
			pst.setString(12, txtComplementoEndfunc.getText());
			pst.setString(13, txtLoginFunc.getText());
			pst.setString(14, txtSenhaFunc.getText());
			pst.setString(15, txtEmailFunc.getText());
			pst.setString(16, txtIdFunc.getText());

			// Valida��o de campos obrigat�rio

			if ((txtCpfFunc.getText().isEmpty()) || (txtNomeFunc.getText().isEmpty())
					|| (txtLoginFunc.getText().isEmpty()) || (txtSenhaFunc.getText().isEmpty())
					|| (txtEmailFunc.getText().isEmpty())) {
				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");
			} else {
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Funcion�rio alterado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao alterar o  Funcion�rio");
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todos para remover um usu�rio */

	private void removerFuncionario() {
		String removeFuncionario = "delete from tb_funcionarios where idFunc = ?";
		try {
			pst = conex.prepareStatement(removeFuncionario);
			pst.setString(1, txtIdFunc.getText());
			// Antes de remover o funcion�rio confirmar
			// A vari�vel abaixo recebe a op��o da caixa de di�logo
			int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover este funcion�rio?",
					"Aten��o", JOptionPane.YES_NO_OPTION);
			if (confirma == JOptionPane.YES_NO_OPTION) {
				int removido = pst.executeUpdate();
				if (removido == 1) {
					JOptionPane.showMessageDialog(null, "Funcion�rio removido com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "N�o foi poss�vel remover funcion�rio");
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para limpar os campos */

	private void limpar() {
		txtIdFunc.setText(null);
		txtNomeFunc.setText(null);
		txtDataNascimento.setText(null);
		txtCpfFunc.setText(null);
		txtCargoFunc.setText(null);
		txtEmailFunc.setText(null);
		txtLoginFunc.setText(null);
		txtSenhaFunc.setText(null);
		txtCepFunc.setText(null);
		txtCidadeFunc.setText(null);
		txtBairroFunc.setText(null);
		txtRuaFunc.setText(null);
		txtComplementoEndfunc.setText(null);
		txtFone1Func.setText(null);
		txtFone2Func.setText(null);
		txtEstado.setText(null);
	}

	private JTextField txtIdFunc;
	private JTextField txtNomeFunc;
	private JTextField txtDataNascimento;
	private JTextField txtCpfFunc;
	private JTextField txtCargoFunc;
	private JTextField txtEmailFunc;
	private JTextField txtLoginFunc;
	private JTextField txtSenhaFunc;
	private JTextField txtCepFunc;
	private JTextField txtCidadeFunc;
	private JTextField txtBairroFunc;
	private JTextField txtRuaFunc;
	private JTextField txtComplementoEndfunc;
	private JTextField txtFuncPesquisaNome;
	private JTextField txtFone1Func;
	private JTextField txtFone2Func;
	private JTextField txtEstado;
	private JTextField txtUsuPesquisaNomeF;
	private JTable tblFuncionario;

	private void pesquisarNomeF() {
		String pesquisaNomeF = "select * from tb_funcionarios where nomeFunc like ?";
		try {
			pst = conex.prepareStatement(pesquisaNomeF); // Passando o conte�do da caixa de
			// pesquisa para o ? // Aten��o ao "%" - continua��o da String pesquisarNome
			pst.setString(1, txtNomeFunc.getText() + "%");
			rs = pst.executeQuery(); // A linha abaixo usa a biblioteca rs2xml.jar para preencher a tabela
			tblFuncionario.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FuncionarioComanda frame = new FuncionarioComanda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// Por algum motivo deu erro ???
	// M�todo para setar os campos do formul�rio
/*	private void setarCamposF() {
		int setarF = tblFuncionario.getSelectedRow();// linha da tabela
		txtIdFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 0).toString());
		txtCargoFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 1).toString());
		txtCpfFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 2).toString());
		txtNomeFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 3).toString());
		txtDataNascimento.setText(tblFuncionario.getModel().getValueAt(setarF, 4).toString());
		txtFone1Func.setText(tblFuncionario.getModel().getValueAt(setarF, 5).toString());
		txtFone2Func.setText(tblFuncionario.getModel().getValueAt(setarF, 6).toString());
		txtCepFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 7).toString());
		txtCidadeFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 8).toString());
		txtBairroFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 9).toString());
		txtRuaFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 10).toString());
		txtEstado.setText(tblFuncionario.getModel().getValueAt(setarF, 11).toString());
		txtComplementoEndfunc.setText(tblFuncionario.getModel().getValueAt(setarF, 12).toString());
		txtLoginFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 13).toString());
		txtSenhaFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 14).toString());
		txtEmailFunc.setText(tblFuncionario.getModel().getValueAt(setarF, 15).toString());
	}*/
	/**
	 * Create the frame.
	 */
	public FuncionarioComanda() {
		setIconifiable(true);
		setClosable(true);
		setTitle("Funcion\u00E1rio");
		setResizable(true);
		setBounds(0, 0, 974, 727);
		getContentPane().setLayout(null);

		JLabel lblIdFunc = new JLabel("* ID Funcion\u00E1rio");
		lblIdFunc.setBounds(10, 11, 87, 14);
		getContentPane().add(lblIdFunc);

		JLabel lblNascimento = new JLabel("NASCIMENTO");
		lblNascimento.setBounds(14, 58, 87, 14);
		getContentPane().add(lblNascimento);

		JLabel lblCpf = new JLabel("* CPF");
		lblCpf.setBounds(10, 90, 71, 14);
		getContentPane().add(lblCpf);

		JLabel lblFuncionario = new JLabel("* FUNCION\u00C1RIO");
		lblFuncionario.setBounds(4, 36, 87, 14);
		getContentPane().add(lblFuncionario);

		JLabel lblCargofunc = new JLabel("CARGO");
		lblCargofunc.setBounds(277, 11, 87, 14);
		getContentPane().add(lblCargofunc);

		JLabel lblEmailfunc = new JLabel("E-MAIL");
		lblEmailfunc.setBounds(277, 36, 87, 14);
		getContentPane().add(lblEmailfunc);

		JLabel lblLogin = new JLabel("* LOGIN");
		lblLogin.setBounds(277, 61, 87, 14);
		getContentPane().add(lblLogin);

		JLabel lblSenha = new JLabel("* SENHA");
		lblSenha.setBounds(277, 90, 87, 14);
		getContentPane().add(lblSenha);

		JLabel lblCep = new JLabel("CEP");
		lblCep.setBounds(277, 115, 87, 14);
		getContentPane().add(lblCep);

		JLabel lblRuafunc = new JLabel("RUA");
		lblRuafunc.setBounds(514, 61, 70, 14);
		getContentPane().add(lblRuafunc);

		JLabel lblComplementofunc = new JLabel("COMPLEMENTO");
		lblComplementofunc.setBounds(498, 86, 122, 14);
		getContentPane().add(lblComplementofunc);

		JLabel lblFonefunc = new JLabel("FONE 1");
		lblFonefunc.setBounds(508, 115, 86, 14);
		getContentPane().add(lblFonefunc);

		JLabel lblFonefunc_1 = new JLabel("FONE 2");
		lblFonefunc_1.setBounds(514, 140, 86, 14);
		getContentPane().add(lblFonefunc_1);

		JLabel lblBairro = new JLabel("BAIRRO");
		lblBairro.setBounds(514, 36, 70, 14);
		getContentPane().add(lblBairro);

		txtIdFunc = new JTextField();
		txtIdFunc.setBounds(91, 5, 164, 20);
		getContentPane().add(txtIdFunc);
		txtIdFunc.setColumns(10);

		txtNomeFunc = new JTextField();
		txtNomeFunc.setColumns(10);
		txtNomeFunc.setBounds(91, 30, 164, 20);
		getContentPane().add(txtNomeFunc);

		txtDataNascimento = new JTextField();
		txtDataNascimento.setColumns(10);
		txtDataNascimento.setBounds(91, 55, 164, 20);
		getContentPane().add(txtDataNascimento);

		txtCpfFunc = new JTextField();
		txtCpfFunc.setColumns(10);
		txtCpfFunc.setBounds(91, 84, 164, 20);
		getContentPane().add(txtCpfFunc);

		txtCargoFunc = new JTextField();
		txtCargoFunc.setBounds(358, 5, 130, 20);
		getContentPane().add(txtCargoFunc);
		txtCargoFunc.setColumns(10);

		txtEmailFunc = new JTextField();
		txtEmailFunc.setColumns(10);
		txtEmailFunc.setBounds(358, 30, 130, 20);
		getContentPane().add(txtEmailFunc);

		txtLoginFunc = new JTextField();
		txtLoginFunc.setColumns(10);
		txtLoginFunc.setBounds(358, 55, 130, 20);
		getContentPane().add(txtLoginFunc);

		txtSenhaFunc = new JTextField();
		txtSenhaFunc.setColumns(10);
		txtSenhaFunc.setBounds(358, 80, 130, 20);
		getContentPane().add(txtSenhaFunc);

		txtCepFunc = new JTextField();
		txtCepFunc.setColumns(10);
		txtCepFunc.setBounds(358, 109, 130, 20);
		getContentPane().add(txtCepFunc);

		txtCidadeFunc = new JTextField();
		txtCidadeFunc.setColumns(10);
		txtCidadeFunc.setBounds(594, 5, 130, 20);
		getContentPane().add(txtCidadeFunc);

		txtBairroFunc = new JTextField();
		txtBairroFunc.setColumns(10);
		txtBairroFunc.setBounds(594, 30, 130, 20);
		getContentPane().add(txtBairroFunc);

		txtRuaFunc = new JTextField();
		txtRuaFunc.setColumns(10);
		txtRuaFunc.setBounds(594, 55, 130, 20);
		getContentPane().add(txtRuaFunc);

		txtComplementoEndfunc = new JTextField();
		txtComplementoEndfunc.setColumns(10);
		txtComplementoEndfunc.setBounds(594, 80, 130, 20);
		getContentPane().add(txtComplementoEndfunc);

		txtFone1Func = new JTextField();
		txtFone1Func.setColumns(10);
		txtFone1Func.setBounds(594, 112, 130, 20);
		getContentPane().add(txtFone1Func);

		txtFone2Func = new JTextField();
		txtFone2Func.setColumns(10);
		txtFone2Func.setBounds(594, 137, 130, 20);
		getContentPane().add(txtFone2Func);

		JLabel lblCidade = new JLabel("CIDADE");
		lblCidade.setBounds(514, 11, 70, 14);
		getContentPane().add(lblCidade);

		txtEstado = new JTextField();
		txtEstado.setColumns(10);
		txtEstado.setBounds(91, 109, 164, 20);
		getContentPane().add(txtEstado);

		JLabel lblEstado = new JLabel("ESTADO");
		lblEstado.setBounds(10, 112, 71, 14);
		getContentPane().add(lblEstado);

		JButton btnAdicionar = new JButton("");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				adicionarFuncionario();
			}
		});
		btnAdicionar.setIcon(
				new ImageIcon(FuncionarioComanda.class.getResource("/br/com/comandaRestaurante/icones/create.png")));
		btnAdicionar.setBounds(91, 377, 89, 82);
		getContentPane().add(btnAdicionar);

		JButton btnPesquisar = new JButton("");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pesquisarFuncionario();
			}
		});
		btnPesquisar.setIcon(
				new ImageIcon(FuncionarioComanda.class.getResource("/br/com/comandaRestaurante/icones/read.png")));
		btnPesquisar.setBounds(229, 377, 89, 82);
		getContentPane().add(btnPesquisar);

		JButton btnAlterar = new JButton("");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				alterarFuncionario();
			}
		});
		btnAlterar.setIcon(
				new ImageIcon(FuncionarioComanda.class.getResource("/br/com/comandaRestaurante/icones/update.png")));
		btnAlterar.setBounds(364, 377, 89, 82);
		getContentPane().add(btnAlterar);

		JButton btnExcluir = new JButton("");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removerFuncionario();
			}
		});
		btnExcluir.setIcon(
				new ImageIcon(FuncionarioComanda.class.getResource("/br/com/comandaRestaurante/icones/delete.png")));
		btnExcluir.setBounds(494, 377, 89, 82);
		getContentPane().add(btnExcluir);

		JLabel lblCamposObrigatrio = new JLabel("* Campos obrigat\u00F3rio");
		lblCamposObrigatrio.setBounds(10, 140, 130, 14);
		getContentPane().add(lblCamposObrigatrio);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(
				new ImageIcon(FuncionarioComanda.class.getResource("/br/com/comandaRestaurante/icones/pesquisar.png")));
		lblNewLabel_1.setBounds(407, 140, 46, 56);
		getContentPane().add(lblNewLabel_1);

		// Evento ao preencher a caixa de texto

		txtFuncPesquisaNome = new JTextField();
		txtFuncPesquisaNome.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
				pesquisarNomeF();

			}
		});

		txtFuncPesquisaNome.setBounds(214, 159, 183, 20);
		getContentPane().add(txtFuncPesquisaNome);
		txtFuncPesquisaNome.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 190, 714, 165);
		getContentPane().add(scrollPane);

		// Evento clicar na linha da tabela

		tblFuncionario = new JTable();
		tblFuncionario.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				//Por algum motivo deu erro ???
				//setarCamposF();
			}
		});

		tblFuncionario.setModel(new DefaultTableModel(
				new Object[][] {
				{ null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null },
				{ null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null },
				{ null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null },
				{ null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null },
				{ null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null },
				{ null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null },
				{ null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null }, },
				new String[] { "ID", "FUNCIONARIO", "NASCIMENTO", "CPF", "ESTADO", "CARGO", "EMAIL", "LOGIN", "SENHA",
						"CEP", "CIDADE", "BAIRRO", "RUA", "COMPLEMENTO", "FONE1 ", "FONE2" }));
		scrollPane.setViewportView(tblFuncionario);

		// Importante !!! -> Usar o m�todo conector() do M�dulo de Conex�o

		conex = ConexaoBancoDados.conect();
	}
}
