package br.com.comandaRestaurante.formularios;

import java.sql.*;
import br.com.comandaRestaurante.conex.*;
import net.proteanit.sql.DbUtils;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ClienteComanda extends JInternalFrame {
	/* Objetos e vari�veis para trabalhar com o sql */
	Connection conex = null; // Esse faz a conex�o
	PreparedStatement pst = null;// Esse permite fazer altera��es no banco de dados
	ResultSet rs = null;// Esse traz os resultados do sql

	/*********** M�todos **********/

	// Pesquisar Cliente
	private void PesquisarCiente() {
		String pesquisaCli = "select * from tb_clientes where idcli = ?";
		// Tratamento de Exce��es
		try {
			// A linha abaixo prepara "digita" o comando sql
			pst = conex.prepareStatement(pesquisaCli);
			// A linha substitui o par�metro ? pelo o que foi digitado na caixa de texto
			// txtIdCli
			pst.setString(1, txtIdCli.getText());
			// A linha abaixo executa o comando
			rs = pst.executeQuery();
			// Estrutura que verifica se existe um funcion�rio
			if (rs.next()) {
				txtNomeCli.setText(rs.getString(2));
				txtCpfCli.setText(rs.getString(3));
				txtEmailCli.setText(rs.getString(4));
				txtCepCli.setText(rs.getString(5));
				txtCidadeCli.setText(rs.getString(6));
				txtBairroCli.setText(rs.getString(7));
				txtRuaCli.setText(rs.getString(8));
				txtComplementoEndCli.setText(rs.getString(9));
				txtFone1Cli.setText(rs.getString(10));
				txtFone2Cli.setText(rs.getString(11));

			} else {

				JOptionPane.showMessageDialog(null, "Cliente n�o cadastrado");
				limpar();
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para adicionar os Clientes */
	private void adicionarCliente() {
		String adicionaCli = "insert into tb_clientes(idCli,nomeCli,cpfCli,emailCli,cepCli,cidadeCli,bairroCli,ruaCli,complementoEndCli,fone1Cli,fone2Cli) values (?,?,?,?,?,?,?,?,?,?,?)";
		try {
			pst = conex.prepareStatement(adicionaCli);
			pst.setString(1, txtIdCli.getText());
			pst.setString(2, txtNomeCli.getText());
			pst.setString(3, txtCpfCli.getText());
			pst.setString(4, txtEmailCli.getText());
			pst.setString(5, txtCepCli.getText());
			pst.setString(6, txtCidadeCli.getText());
			pst.setString(7, txtBairroCli.getText());
			pst.setString(8, txtRuaCli.getText());
			pst.setString(9, txtComplementoEndCli.getText());
			pst.setString(10, txtFone1Cli.getText());
			pst.setString(11, txtFone2Cli.getText());

			// Valida��o dos campos obrigat�rios
			if ((txtNomeCli.getText().isEmpty())) {
				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");
			} else {
				// CRIANDO UMA V�RIAV�L PARA EXECUTAR A QUERY E EXIBIR UMA MENSAGEM AO USU�RIO
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao cadastrar Cliente");
				}

			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para alterar Cliente */

	private void alterarCliente() {
		String alterarCli = "update tb_clientes set nomeCli = ?,cpfCli = ?,emailCli = ?,cepCli = ?,cidadeCli = ?,bairroCli = ?,ruaCli = ?,complementoEndCli = ?,fone1Cli = ?,fone2Cli = ? where idCli = ?";
		try {
			pst = conex.prepareStatement(alterarCli);
			pst.setString(1, txtNomeCli.getText());
			pst.setString(2, txtCpfCli.getText());
			pst.setString(3, txtEmailCli.getText());
			pst.setString(4, txtCepCli.getText());
			pst.setString(5, txtCidadeCli.getText());
			pst.setString(6, txtBairroCli.getText());
			pst.setString(7, txtRuaCli.getText());
			pst.setString(8, txtComplementoEndCli.getText());
			pst.setString(9, txtFone1Cli.getText());
			pst.setString(10, txtFone2Cli.getText());
			pst.setString(11, txtIdCli.getText());

			// Valida��o de campos obrigat�rio
			if ((txtNomeCli.getText().isEmpty())) {
				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");
			} else {
				// CRIANDO UMA V�RIAV�L PARA EXECUTAR A QUERY E EXIBIR UMA MENSAGEM AO USU�RIO
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Cliente alterado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao alterar Cliente");
				}

			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todos para remover um Cliente */

	private void removerCliente() {
		String removeCli = "delete from tb_clientes where idcli = ?";
		try {
			pst = conex.prepareStatement(removeCli);
			pst.setString(1, txtIdCli.getText());
			// Antes de remover o cliente confirmar
			// A vari�vel abaixo recebe a op��o da caixa de di�logo
			int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover este cliente?",
					"Aten��o", JOptionPane.YES_NO_OPTION);
			if (confirma == JOptionPane.YES_NO_OPTION) {
				int removido = pst.executeUpdate();
				if (removido == 1) {
					JOptionPane.showMessageDialog(null, "Cliente removido com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "N�o foi poss�vel remover cliente");
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para limpar os campos */

	private void limpar() {
		txtIdCli.setText(null);
		txtNomeCli.setText(null);
		txtCpfCli.setText(null);
		txtEmailCli.setText(null);
		txtCepCli.setText(null);
		txtCidadeCli.setText(null);
		txtBairroCli.setText(null);
		txtRuaCli.setText(null);
		txtComplementoEndCli.setText(null);
		txtFone1Cli.setText(null);
		txtFone2Cli.setText(null);

	}

	private JTextField txtIdCli;
	private JTextField txtNomeCli;
	private JTextField txtFone2Cli;
	private JTextField txtFone1Cli;
	private JTextField txtCidadeCli;
	private JTextField txtComplementoEndCli;
	private JTextField txtRuaCli;
	private JTextField txtPesquisaCli;
	private JTable tblCliente;
	private JTextField txtCepCli;
	private JTextField txtCpfCli;
	private JTextField txtBairroCli;
	private JTextField txtEmailCli;

	private void pesquisarNomeC() {
		String pesquisaNomeC = "select * from tb_clientes where nomeCli like ?";
		try {
			pst = conex.prepareStatement(pesquisaNomeC); // Passando o conte�do da caixa de
			// pesquisa para o ? // Aten��o ao "%" - continua��o da String pesquisarNome
			pst.setString(1, txtNomeCli.getText() + "%");
			rs = pst.executeQuery(); // A linha abaixo usa a biblioteca rs2xml.jar para preencher a tabela
			tblCliente.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClienteComanda frame = new ClienteComanda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	// Por algum motivo deu erro ???
	// M�todo para setar os campos do formul�rio
/*	private void setarCamposC() {
		int setarC = tblCliente.getSelectedRow();// linha da tabela
		txtIdCli.setText(tblCliente.getModel().getValueAt(setarC, 0).toString());
		txtNomeCli.setText(tblCliente.getModel().getValueAt(setarC, 1).toString());
		txtCpfCli.setText(tblCliente.getModel().getValueAt(setarC, 2).toString());
		txtEmailCli.setText(tblCliente.getModel().getValueAt(setarC, 3).toString());
		txtCepCli.setText(tblCliente.getModel().getValueAt(setarC, 4).toString());
		txtCidadeCli.setText(tblCliente.getModel().getValueAt(setarC, 5).toString());
		txtBairroCli.setText(tblCliente.getModel().getValueAt(setarC, 6).toString());
		txtRuaCli.setText(tblCliente.getModel().getValueAt(setarC, 7).toString());
		txtComplementoEndCli.setText(tblCliente.getModel().getValueAt(setarC, 8).toString());
		txtFone1Cli.setText(tblCliente.getModel().getValueAt(setarC, 9).toString());
		txtFone2Cli.setText(tblCliente.getModel().getValueAt(setarC, 10).toString());

	}*/

	/**
	 * Create the frame.
	 */
	public ClienteComanda() {
		setIconifiable(true);
		setClosable(true);
		setResizable(true);
		setTitle("Cliente");
		setBounds(0, 0, 974, 727);
		getContentPane().setLayout(null);

		JLabel lblidcli = new JLabel("ID CLIENTE");
		lblidcli.setBounds(10, 17, 71, 14);
		getContentPane().add(lblidcli);

		JLabel lblNomeCli = new JLabel("NOME");
		lblNomeCli.setBounds(6, 42, 71, 14);
		getContentPane().add(lblNomeCli);

		JLabel label_5 = new JLabel("* Campos obrigat\u00F3rio");
		label_5.setBounds(10, 146, 130, 14);
		getContentPane().add(label_5);

		JLabel lblruacli = new JLabel("RUA");
		lblruacli.setBounds(261, 92, 87, 14);
		getContentPane().add(lblruacli);

		JLabel lblcomplemento = new JLabel("COMPLEMENTO");
		lblcomplemento.setBounds(261, 117, 87, 14);
		getContentPane().add(lblcomplemento);

		JLabel lblcidade = new JLabel("CIDADE");
		lblcidade.setBounds(261, 42, 87, 14);
		getContentPane().add(lblcidade);

		JLabel lblfone1 = new JLabel("FONE 1");
		lblfone1.setBounds(532, 16, 87, 14);
		getContentPane().add(lblfone1);

		JLabel lblfone2 = new JLabel("FONE 2");
		lblfone2.setBounds(532, 45, 87, 14);
		getContentPane().add(lblfone2);

		txtIdCli = new JTextField();
		txtIdCli.setColumns(10);
		txtIdCli.setBounds(91, 11, 164, 20);
		getContentPane().add(txtIdCli);

		txtNomeCli = new JTextField();
		txtNomeCli.setColumns(10);
		txtNomeCli.setBounds(87, 39, 164, 20);
		getContentPane().add(txtNomeCli);

		txtFone2Cli = new JTextField();
		txtFone2Cli.setColumns(10);
		txtFone2Cli.setBounds(596, 39, 164, 20);
		getContentPane().add(txtFone2Cli);

		txtFone1Cli = new JTextField();
		txtFone1Cli.setColumns(10);
		txtFone1Cli.setBounds(596, 14, 164, 20);
		getContentPane().add(txtFone1Cli);

		txtCidadeCli = new JTextField();
		txtCidadeCli.setColumns(10);
		txtCidadeCli.setBounds(342, 36, 164, 20);
		getContentPane().add(txtCidadeCli);

		txtComplementoEndCli = new JTextField();
		txtComplementoEndCli.setColumns(10);
		txtComplementoEndCli.setBounds(342, 117, 164, 20);
		getContentPane().add(txtComplementoEndCli);

		txtRuaCli = new JTextField();
		txtRuaCli.setColumns(10);
		txtRuaCli.setBounds(342, 86, 164, 20);
		getContentPane().add(txtRuaCli);

		txtPesquisaCli = new JTextField();
		txtPesquisaCli.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				pesquisarNomeC();
			}
		});
		txtPesquisaCli.setColumns(10);
		txtPesquisaCli.setBounds(224, 160, 183, 20);
		getContentPane().add(txtPesquisaCli);

		JLabel label_16 = new JLabel("");
		label_16.setIcon(
				new ImageIcon(ClienteComanda.class.getResource("/br/com/comandaRestaurante/icones/pesquisar.png")));
		label_16.setBounds(417, 141, 46, 56);
		getContentPane().add(label_16);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 202, 714, 124);
		getContentPane().add(scrollPane);

		JButton btnAdicionar = new JButton("");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarCliente();
			}
		});
		btnAdicionar.setIcon(
				new ImageIcon(ClienteComanda.class.getResource("/br/com/comandaRestaurante/icones/create.png")));
		btnAdicionar.setBounds(101, 378, 89, 82);
		getContentPane().add(btnAdicionar);

		JButton btnPesquisar = new JButton("");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PesquisarCiente();
			}
		});
		btnPesquisar
				.setIcon(new ImageIcon(ClienteComanda.class.getResource("/br/com/comandaRestaurante/icones/read.png")));
		btnPesquisar.setBounds(239, 378, 89, 82);
		getContentPane().add(btnPesquisar);

		JButton btnAlterar = new JButton("");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alterarCliente();
			}
		});
		btnAlterar.setIcon(
				new ImageIcon(ClienteComanda.class.getResource("/br/com/comandaRestaurante/icones/update.png")));
		btnAlterar.setBounds(374, 378, 89, 82);
		getContentPane().add(btnAlterar);

		JButton btnExcluir = new JButton("");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removerCliente();
			}
		});
		btnExcluir.setIcon(
				new ImageIcon(ClienteComanda.class.getResource("/br/com/comandaRestaurante/icones/delete.png")));
		btnExcluir.setBounds(504, 378, 89, 82);
		getContentPane().add(btnExcluir);

		tblCliente = new JTable();
		tblCliente.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// Por algum motivo deu erro ???
				//setarCamposC();
			}
		});
		tblCliente.setModel(new DefaultTableModel(
				new Object[][] { { null, null, null, null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null, null, null, null },
						{ null, null, null, null, null, null, null, null, null, null, null }, },
				new String[] { "ID CLIENTE", "NOME", "CPF", "E-MAIL", "CEP", "CIDADE", "BAIRRO", "RUA ", "COMPLEMENTO",
						"FONE 1", "FONE 2" }));
		scrollPane.setViewportView(tblCliente);

		JLabel lblCep = new JLabel("CEP");
		lblCep.setBounds(261, 17, 71, 14);
		getContentPane().add(lblCep);

		txtCepCli = new JTextField();
		txtCepCli.setColumns(10);
		txtCepCli.setBounds(342, 11, 164, 20);
		getContentPane().add(txtCepCli);

		JLabel lblCpfCliente = new JLabel("CPF");
		lblCpfCliente.setBounds(6, 67, 71, 14);
		getContentPane().add(lblCpfCliente);

		txtCpfCli = new JTextField();
		txtCpfCli.setColumns(10);
		txtCpfCli.setBounds(91, 64, 164, 20);
		getContentPane().add(txtCpfCli);

		txtBairroCli = new JTextField();
		txtBairroCli.setColumns(10);
		txtBairroCli.setBounds(342, 61, 164, 20);
		getContentPane().add(txtBairroCli);

		JLabel lblBairro = new JLabel("BAIRRO");
		lblBairro.setBounds(261, 64, 71, 14);
		getContentPane().add(lblBairro);

		txtEmailCli = new JTextField();
		txtEmailCli.setColumns(10);
		txtEmailCli.setBounds(87, 90, 164, 20);
		getContentPane().add(txtEmailCli);

		JLabel lblEmail = new JLabel("E-MAIL");
		lblEmail.setBounds(6, 96, 70, 14);
		getContentPane().add(lblEmail);

		// Importante !!! -> Usar o m�todo conector() do M�dulo de Conex�o

		conex = ConexaoBancoDados.conect();
	}
}
