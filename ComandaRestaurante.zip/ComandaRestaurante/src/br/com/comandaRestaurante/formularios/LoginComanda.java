package br.com.comandaRestaurante.formularios;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.ImageIcon;



import java.awt.Dialog.ModalExclusionType;
import java.awt.Color;

//Importar recursos (java.sql.*) e ModuloConexao 
import java.sql.*;
import br.com.comandaRestaurante.conex.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class LoginComanda extends JFrame {
	// Vari�veis e objetos (Criar sempre dentro do m�todo principal)
	// Criando usu�rios e objetos para "usar" o banco de dados
	Connection conex = null; // Esse faz a conex�o
	PreparedStatement pst = null; // Esse permite fazer altera��es no banco de dados
	ResultSet rs = null; // Esse traz os resultados do sql
	/* M�todo Logar */

	private void logar() {
		String login = "select * from tb_funcionarios where loginfunc=? and senhafunc=?";
		try {
			pst = conex.prepareStatement(login);
			pst.setString(1, txtUsuario.getText());
			pst.setString(2, txtSenha.getText());
			rs = pst.executeQuery();
			if (rs.next()) {// Se existir usu�rio e senha correspondente
				ComandaPrincipalR comanda = new ComandaPrincipalR();
				comanda.setVisible(true);
				dispose();
			} else {
				JOptionPane.showMessageDialog(null, "Usu�rio e/ou senha inv�lido(s)");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private JPanel contentPane;
	private JTextField txtUsuario;
	private JPasswordField txtSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginComanda frame = new LoginComanda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginComanda() {
		setBackground(Color.WHITE);
		setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		setResizable(false);
		setTitle("Comanda");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setBounds(75, 92, 46, 14);
		contentPane.add(lblUsuario);

		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(75, 164, 46, 14);
		contentPane.add(lblSenha);

		txtUsuario = new JTextField();
		txtUsuario.setBounds(131, 84, 163, 30);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);

		txtSenha = new JPasswordField();
		txtSenha.setBounds(131, 156, 163, 30);
		contentPane.add(txtSenha);

		// Login

		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logar();
				
				// O c�digo abaixo loga no sistema sem senha
				/*
				 * Principal principal = new Principal(); principal.setVisible(true); dispose();
				 */
			}
		});
		btnLogin.setBounds(205, 211, 89, 23);
		contentPane.add(btnLogin);

		JLabel lblStatus = new JLabel("");
		lblStatus.setIcon(new ImageIcon(LoginComanda.class.getResource("/br/com/comandaRestaurante/icones/dberror.png")));
		lblStatus.setBounds(44, 211, 57, 35);
		contentPane.add(lblStatus);
		
		// Estabelecer a conex�o com o banco de dados dentro do construtor ap�s cria��o
		// dos objetos

		conex = ConexaoBancoDados.conect();

		if (conex != null) {
			// A linha abaixo comentada serve para testarmos se BD esta se conectando
			// System.out.println("conectado");
			lblStatus.setIcon(new ImageIcon(LoginComanda.class.getResource("/br/com/comandaRestaurante/icones/dbok.png")));
		} else {
			// System.out.println("n�o conectado");
			lblStatus.setIcon(new ImageIcon(LoginComanda.class.getResource("/br/com/comandaRestaurante/icones/dberror.png")));
		}
		/* Fim do construtor */
	}
}