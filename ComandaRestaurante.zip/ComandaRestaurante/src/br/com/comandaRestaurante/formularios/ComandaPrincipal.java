package br.com.comandaRestaurante.formularios;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.DesktopPaneUI;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Color;
import javax.swing.JDesktopPane;
import javax.swing.JButton;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/*
 * Abaixo importamos as classes 
 * import java.sql.*;
import br.com.infox.dal.ModuloConexao;
para ajudar a conex�o com o banco de dados 
 * */
import java.sql.*;
import br.com.comandaRestaurante.conex.*;
import net.proteanit.sql.DbUtils;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ComandaPrincipal extends JInternalFrame {

	/* Objetos e vari�veis para trabalhar com o sql */
	Connection conex = null; // Esse faz a conex�o
	PreparedStatement pst = null;// Esse permite fazer altera��es no banco de dados
	ResultSet rs = null;// Esse traz os resultados do sql

	/*********** M�todos **********/


	private JPanel contentPane;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField txtQuant;
	private JTextField txtProduto;
	private JTextField txtMesa;
	private JTextField txtPessoa;
	private JTextField txtIdP;
	private JTextField txtTotal;
	private JTable table_1;
	
	
/*	private void pesquisarNomeM() {
		String pesquisaMesa = "select * from tb_funcionarios where numeroMesa like ?";
		try {
			pst = conex.prepareStatement(pesquisaMesa); // Passando o conte�do da caixa de
			// pesquisa para o ? // Aten��o ao "%" - continua��o da String pesquisarNome
			pst.setString(1, txtMesa.getText() + "%");
			rs = pst.executeQuery(); // A linha abaixo usa a biblioteca rs2xml.jar para preencher a tabela
			tbl.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (Exception e) {
			System.out.println(e);
		}
	}*/

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ComandaPrincipal frame = new ComandaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ComandaPrincipal() {
		setClosable(true);
		setIconifiable(true);
		setTitle("Comanda Eletr\u00F4nica");
		setResizable(true);
		setBounds(0, 0, 973, 727);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnNewButton = new JButton("Excluir");
		btnNewButton.setBounds(10, 415, 104, 23);
		contentPane.add(btnNewButton);

		JButton btnTransferir = new JButton("Transferir");
		btnTransferir.setBounds(136, 415, 104, 23);
		contentPane.add(btnTransferir);

		JButton btnConta = new JButton("Conta");
		btnConta.setBounds(136, 449, 104, 23);
		contentPane.add(btnConta);

		JButton btnMesas = new JButton("Mesas");
		btnMesas.setBounds(8, 449, 104, 23);
		contentPane.add(btnMesas);

		JButton btnServio = new JButton("Servi\u00E7o");
		btnServio.setBounds(136, 483, 104, 23);
		contentPane.add(btnServio);

		JButton btnDesbloq = new JButton("Desbloq.");
		btnDesbloq.setBounds(8, 483, 104, 23);
		contentPane.add(btnDesbloq);

		JButton btnCalculadora = new JButton("Calculadora");
		btnCalculadora.setBounds(71, 517, 104, 23);
		contentPane.add(btnCalculadora);

		JDesktopPane desktopPane_2 = new JDesktopPane();
		desktopPane_2.setBackground(SystemColor.activeCaption);
		desktopPane_2.setBounds(520, 392, 264, 178);
		contentPane.add(desktopPane_2);

		JLabel lblTotalProduto = new JLabel("Total Produto:");
		lblTotalProduto.setBounds(10, 15, 104, 14);
		desktopPane_2.add(lblTotalProduto);

		JLabel lblTotalACobrar = new JLabel("Total a Cobrar:");
		lblTotalACobrar.setBounds(10, 103, 83, 20);
		desktopPane_2.add(lblTotalACobrar);

		JLabel lblTotalRecebido = new JLabel("Total Recebido:");
		lblTotalRecebido.setBounds(10, 128, 104, 20);
		desktopPane_2.add(lblTotalRecebido);

		JButton btnServio_1 = new JButton("Servi\u00E7o");
		btnServio_1.setBounds(10, 40, 104, 23);
		desktopPane_2.add(btnServio_1);

		JButton btnDesconto = new JButton("Desconto");
		btnDesconto.setBounds(10, 69, 104, 23);
		desktopPane_2.add(btnDesconto);

		textField_3 = new JTextField();
		textField_3.setBounds(124, 40, 132, 23);
		desktopPane_2.add(textField_3);
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(124, 69, 132, 23);
		desktopPane_2.add(textField_4);

		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(96, 102, 160, 23);
		desktopPane_2.add(textField_5);

		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(96, 127, 160, 23);
		desktopPane_2.add(textField_6);

		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(96, 152, 160, 23);
		desktopPane_2.add(textField_7);

		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(124, 10, 132, 25);
		desktopPane_2.add(textField_8);

		JLabel lblTroco = new JLabel("Troco:");
		lblTroco.setBounds(10, 153, 83, 20);
		desktopPane_2.add(lblTroco);

		JButton btnBalco = new JButton("Balc\u00E3o");
		btnBalco.setBounds(244, 392, 104, 23);
		contentPane.add(btnBalco);

		JButton btnDelivery = new JButton("Delivery");
		btnDelivery.setBounds(414, 392, 104, 23);
		contentPane.add(btnDelivery);

		JDesktopPane desktopPane_4 = new JDesktopPane();
		desktopPane_4.setBackground(Color.WHITE);
		desktopPane_4.setBounds(10, 31, 774, 351);
		contentPane.add(desktopPane_4);

		JDesktopPane desktopPane_1 = new JDesktopPane();
		desktopPane_1.setBounds(273, 0, 501, 351);
		desktopPane_4.add(desktopPane_1);
		desktopPane_1.setBackground(SystemColor.activeCaption);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 7, 481, 313);
		desktopPane_1.add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setColumnHeaderView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));

		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(0, 0, 240, 351);
		desktopPane_4.add(desktopPane);
		desktopPane.setBackground(SystemColor.activeCaption);

		JLabel lblMesa = new JLabel("Mesa");
		lblMesa.setBounds(10, 11, 46, 14);
		desktopPane.add(lblMesa);

		JLabel lblpessoas = new JLabel("Pessoas");
		lblpessoas.setBounds(96, 11, 69, 14);
		desktopPane.add(lblpessoas);

		JLabel lblVendedor = new JLabel("Vendedor");
		lblVendedor.setBounds(10, 66, 46, 14);
		desktopPane.add(lblVendedor);

		JLabel lblQuantidade = new JLabel("Quantidade");
		lblQuantidade.setBounds(10, 141, 90, 14);
		desktopPane.add(lblQuantidade);

		JLabel lblProduto = new JLabel("Produto");
		lblProduto.setBounds(96, 141, 75, 14);
		desktopPane.add(lblProduto);

		JLabel lblX = new JLabel("X");
		lblX.setBounds(84, 141, 22, 14);
		desktopPane.add(lblX);

		JButton btnProdutos = new JButton("Produtos");
		btnProdutos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnProdutos.setBounds(11, 198, 89, 23);
		desktopPane.add(btnProdutos);

		txtQuant = new JTextField();
		txtQuant.setBounds(10, 157, 71, 29);
		desktopPane.add(txtQuant);
		txtQuant.setColumns(10);

		txtProduto = new JTextField();
		txtProduto.setColumns(10);
		txtProduto.setBounds(94, 157, 71, 29);
		desktopPane.add(txtProduto);

		txtMesa = new JTextField();
		txtMesa.setColumns(10);
		txtMesa.setBounds(10, 35, 71, 29);
		desktopPane.add(txtMesa);

		txtPessoa = new JTextField();
		txtPessoa.setColumns(10);
		txtPessoa.setBounds(96, 35, 71, 29);
		desktopPane.add(txtPessoa);

		txtIdP = new JTextField();
		txtIdP.setColumns(10);
		txtIdP.setBounds(10, 86, 71, 29);
		desktopPane.add(txtIdP);
		
		txtTotal = new JTextField();
		txtTotal.setBounds(10, 281, 161, 20);
		desktopPane.add(txtTotal);
		txtTotal.setColumns(10);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setBounds(10, 256, 46, 14);
		desktopPane.add(lblTotal);

		JDesktopPane desktopPane_3 = new JDesktopPane();
		desktopPane_3.setBounds(254, 415, 274, 155);
		contentPane.add(desktopPane_3);
		desktopPane_3.setBackground(SystemColor.activeCaption);

		JLabel lblNewLabel = new JLabel("Pagamento:");
		lblNewLabel.setBounds(10, 0, 77, 25);
		desktopPane_3.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Assinados:");
		lblNewLabel_1.setBounds(10, 126, 77, 14);
		desktopPane_3.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Cart\u00E3o:");
		lblNewLabel_2.setBounds(10, 85, 46, 14);
		desktopPane_3.add(lblNewLabel_2);

		JLabel label = new JLabel("");
		label.setBounds(97, 22, 46, 14);
		desktopPane_3.add(label);

		JLabel lblDinheiro = new JLabel("Dinheiro:");
		lblDinheiro.setBounds(10, 36, 77, 14);
		desktopPane_3.add(lblDinheiro);

		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(72, 122, 160, 23);
		desktopPane_3.add(textField);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(72, 81, 160, 23);
		desktopPane_3.add(textField_1);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(72, 32, 160, 23);
		desktopPane_3.add(textField_2);

		// Importante !!! -> Usar o m�todo conector() do M�dulo de Conex�o

		conex = ConexaoBancoDados.conect();
	}
}
