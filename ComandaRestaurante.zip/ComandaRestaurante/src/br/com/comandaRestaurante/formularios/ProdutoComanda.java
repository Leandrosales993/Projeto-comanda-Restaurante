package br.com.comandaRestaurante.formularios;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JFrame;

/*
 * Abaixo importamos as classes 
 * import java.sql.*;
import br.com.infox.dal.ModuloConexao;
para ajudar a conex�o com o banco de dados 
 * */
import java.sql.*;
import br.com.comandaRestaurante.conex.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProdutoComanda extends JInternalFrame {

	/* Objetos e vari�veis para trabalhar com o sql */
	Connection conex = null; // Esse faz a conex�o
	PreparedStatement pst = null;// Esse permite fazer altera��es no banco de dados
	ResultSet rs = null;// Esse traz os resultados do sql

	/*********** M�todos **********/

	// Pesquisar Produto
	private void pesquisarProduto() {
		String pesquisaproduto = "select * from tb_produto where idProduto = ?";

		// Tratamento de Exce��es
		try {
			// A linha abaixo prepara "digita" o comando sql
			pst = conex.prepareStatement(pesquisaproduto);
			// A linha substitui o par�metro ? pelo o que foi digitado na caixa de texto
			// txtIdF
			pst.setString(1, txtIdProduto.getText());
			// A linha abaixo executa o comando
			rs = pst.executeQuery();
			// Estrutura que verifica se existe um produto
			if (rs.next()) {
				// Preecher os campos do formul�rio
				txtNomeProduto.setText(rs.getString(2));
				txtQuantProduto.setText(rs.getString(3));
				txtVenciProduto.setText(rs.getString(4));
				txtPrecoProduto.setText(rs.getString(5));
				txtIdPedProduto.setText(rs.getString(6));

			} else {
				// Mensagem se n�o existir um funcion�rio cadastrado
				JOptionPane.showMessageDialog(null, "Produto n�o cadastrado");
				limpar();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para adicionar os produtos */

	public void adicionarProduto() {
		String adicionaProduto = "insert into tb_produto (idProduto,nomeProduto,quatidProduto,vencProduto,precoProduto,idpedido) values (?,?,?,?,?,?)";
		try {
			pst = conex.prepareStatement(adicionaProduto);
			pst.setString(1, txtIdProduto.getText());
			pst.setString(2, txtNomeProduto.getText());
			pst.setString(3, txtQuantProduto.getText());
			pst.setString(4, txtVenciProduto.getText());
			pst.setString(5, txtPrecoProduto.getText());
			pst.setString(6, txtIdPedProduto.getText());

			// Valida��o dos campos obrigat�rios
			if ((txtNomeProduto.getText().isEmpty()) || (txtQuantProduto.getText().isEmpty())
					|| (txtVenciProduto.getText().isEmpty()) || (txtPrecoProduto.getText().isEmpty())) {

				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");

			} else {
				// CRIANDO UMA V�RIAV�L PARA EXECUTAR A QUERY E EXIBIR UMA MENSAGEM AO USU�RIO
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Produto cadastrado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao cadastrar Produto");
				}

			}

		} catch (Exception e) {

			System.out.println(e);
		}
	}

	/* M�todo para alterar produtos */

	public void alterarProduto() {
		String alteraProduto = "update tb_produto set nomeProduto = ?,quatidProduto = ?,vencProduto = ?,precoProduto = ?,idpedido = ? where idProduto = ? ";
		try {
			pst = conex.prepareStatement(alteraProduto);

			pst.setString(1, txtNomeProduto.getText());
			pst.setString(2, txtQuantProduto.getText());
			pst.setString(3, txtVenciProduto.getText());
			pst.setString(4, txtPrecoProduto.getText());
			pst.setString(5, txtIdPedProduto.getText());
			pst.setString(6, txtIdProduto.getText());

			// Valida��o dos campos obrigat�rios
			if ((txtNomeProduto.getText().isEmpty()) || (txtQuantProduto.getText().isEmpty())
					|| (txtVenciProduto.getText().isEmpty()) || (txtPrecoProduto.getText().isEmpty())) {

				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");

			} else {
				// CRIANDO UMA V�RIAV�L PARA EXECUTAR A QUERY E EXIBIR UMA MENSAGEM AO USU�RIO
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Produto alterado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao alterar Produto");
				}

			}

		} catch (Exception e) {

			System.out.println(e);
		}
	}

	/* M�todos para remover um produto */

	private void removerProduto() {
		String removeProduto = "delete from tb_produto where idProduto = ?";
		try {
			pst = conex.prepareStatement(removeProduto);
			pst.setString(1, txtIdProduto.getText());
			// Antes de remover o funcion�rio confirmar
			// A vari�vel abaixo recebe a op��o da caixa de di�logo
			int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover este Produto?",
					"Aten��o", JOptionPane.YES_NO_OPTION);
			if (confirma == JOptionPane.YES_NO_OPTION) {
				int removido = pst.executeUpdate();
				if (removido == 1) {
					JOptionPane.showMessageDialog(null, "Produto removido com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "N�o foi poss�vel remover produto");
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para limpar os campos */

	private void limpar() {
		txtIdProduto.setText(null);
		txtNomeProduto.setText(null);
		txtQuantProduto.setText(null);
		txtVenciProduto.setText(null);
		txtPrecoProduto.setText(null);
		txtIdPedProduto.setText(null);

	}

	private JTextField txtIdProduto;
	private JTextField txtNomeProduto;
	private JTextField txtQuantProduto;
	private JTextField txtVenciProduto;
	private JTextField txtPrecoProduto;
	private JTextField txtIdPedProduto;
	private JTextField txtFuncPesquisaProd;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProdutoComanda frame = new ProdutoComanda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProdutoComanda() {
		setIconifiable(true);
		setResizable(true);
		setClosable(true);
		setTitle("Produto");
		setBounds(0, 0, 974, 727);
		getContentPane().setLayout(null);

		JLabel lblIdproduto = new JLabel("ID PRODUTO");
		lblIdproduto.setBounds(10, 11, 103, 14);
		getContentPane().add(lblIdproduto);

		JLabel lblNomeproduto_1 = new JLabel("NOME ");
		lblNomeproduto_1.setBounds(10, 36, 103, 14);
		getContentPane().add(lblNomeproduto_1);

		JLabel lblNomeproduto = new JLabel("QUANTI.");
		lblNomeproduto.setBounds(10, 61, 103, 14);
		getContentPane().add(lblNomeproduto);

		JLabel lblVenciproduto = new JLabel("VENCIMENTO");
		lblVenciproduto.setBounds(10, 90, 103, 14);
		getContentPane().add(lblVenciproduto);

		JLabel lblPrecoproduto = new JLabel("PRE\u00C7O");
		lblPrecoproduto.setBounds(331, 17, 102, 14);
		getContentPane().add(lblPrecoproduto);

		JLabel label_5 = new JLabel("* Campos obrigat\u00F3rio");
		label_5.setBounds(10, 140, 130, 14);
		getContentPane().add(label_5);

		JLabel lblIdpedido = new JLabel("ID PEDIDO");
		lblIdpedido.setBounds(331, 42, 87, 14);
		getContentPane().add(lblIdpedido);

		txtIdProduto = new JTextField();
		txtIdProduto.setColumns(10);
		txtIdProduto.setBounds(146, 11, 164, 20);
		getContentPane().add(txtIdProduto);

		txtNomeProduto = new JTextField();
		txtNomeProduto.setColumns(10);
		txtNomeProduto.setBounds(146, 36, 164, 20);
		getContentPane().add(txtNomeProduto);

		txtQuantProduto = new JTextField();
		txtQuantProduto.setColumns(10);
		txtQuantProduto.setBounds(146, 61, 164, 20);
		getContentPane().add(txtQuantProduto);

		txtVenciProduto = new JTextField();
		txtVenciProduto.setColumns(10);
		txtVenciProduto.setBounds(146, 86, 164, 20);
		getContentPane().add(txtVenciProduto);

		txtPrecoProduto = new JTextField();
		txtPrecoProduto.setColumns(10);
		txtPrecoProduto.setBounds(443, 11, 164, 20);
		getContentPane().add(txtPrecoProduto);

		txtIdPedProduto = new JTextField();
		txtIdPedProduto.setColumns(10);
		txtIdPedProduto.setBounds(443, 39, 130, 20);
		getContentPane().add(txtIdPedProduto);

		JLabel label_8 = new JLabel("");
		label_8.setIcon(
				new ImageIcon(ProdutoComanda.class.getResource("/br/com/comandaRestaurante/icones/pesquisar.png")));
		label_8.setBounds(438, 160, 46, 56);
		getContentPane().add(label_8);

		txtFuncPesquisaProd = new JTextField();
		txtFuncPesquisaProd.setColumns(10);
		txtFuncPesquisaProd.setBounds(245, 179, 183, 20);
		getContentPane().add(txtFuncPesquisaProd);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 221, 714, 106);
		getContentPane().add(scrollPane);

		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, ""},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"ID PRODUTO", "NOME", "QUANTI.", "VENCIMENTO", "PRE\u00C7O", "ID PEDIDO"
			}
		));
		scrollPane.setViewportView(table);

		JButton btnExcluir = new JButton("");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removerProduto();
			}
		});
		btnExcluir.setIcon(new ImageIcon(ProdutoComanda.class.getResource("/br/com/comandaRestaurante/icones/delete.png")));
		btnExcluir.setBounds(549, 368, 89, 82);
		getContentPane().add(btnExcluir);

		JButton btnAlterar = new JButton("");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alterarProduto();
			}
		});
		btnAlterar.setIcon(
				new ImageIcon(ProdutoComanda.class.getResource("/br/com/comandaRestaurante/icones/update.png")));
		btnAlterar.setBounds(419, 368, 89, 82);
		getContentPane().add(btnAlterar);

		JButton btnPesquisar = new JButton("");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pesquisarProduto();
			}
		});
		btnPesquisar.setIcon(new ImageIcon(ProdutoComanda.class.getResource("/br/com/comandaRestaurante/icones/read.png")));
		btnPesquisar.setBounds(284, 368, 89, 82);
		getContentPane().add(btnPesquisar);

		JButton btnAdicionar = new JButton("");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adicionarProduto();
			}
		});
		btnAdicionar.setIcon(
				new ImageIcon(ProdutoComanda.class.getResource("/br/com/comandaRestaurante/icones/create.png")));
		btnAdicionar.setBounds(146, 368, 89, 82);
		getContentPane().add(btnAdicionar);

		conex = ConexaoBancoDados.conect();
	}
}
