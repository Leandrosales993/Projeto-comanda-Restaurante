package br.com.comandaRestaurante.formularios;

import java.awt.EventQueue;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
 * Abaixo importamos as classes 
 * import java.sql.*;
import br.com.infox.dal.ModuloConexao;
para ajudar a conex�o com o banco de dados 
 * */

import java.sql.*;
import br.com.comandaRestaurante.conex.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FornecedorComanda extends JInternalFrame {

	/* Objetos e vari�veis para trabalhar com o sql */
	Connection conex = null; // Esse faz a conex�o
	PreparedStatement pst = null;// Esse permite fazer altera��es no banco de dados
	ResultSet rs = null;// Esse traz os resultados do sql

	/*********** M�todos **********/
	// Pesquisar Fornecedor 

	public void pesquisarFornecedor() {
		String pesquisarForn = "select * from tb_fornecedor where idFornecedor = ?";
		// Tratamento de Exce��es
		try {
			// A linha abaixo prepara "digita" o comando sql
			pst = conex.prepareStatement(pesquisarForn);
			// A linha substitui o par�metro ? pelo o que foi digitado na caixa de texto
			// txtIdF
			pst.setString(1, txtIdFornecedor.getText());
			// A linha abaixo executa o comando
			rs = pst.executeQuery();
			// Estrutura que verifica se existe um Fornecedor 
			if (rs.next()) {
				// Preecher os campos do formul�rio
				txtNomeForne.setText(rs.getString(2));
				txtCnpjForne.setText(rs.getString(3));
				txtEmailForne.setText(rs.getString(4));
				txtCepForne.setText(rs.getString(5));
				txtCidadeForne.setText(rs.getString(6));
				txtBairroForne.setText(rs.getString(7));
				txtRuaForne.setText(rs.getString(8));
				txtComplementoEndForne.setText(rs.getString(9));
				txtFone1Forne.setText(rs.getString(10));
				txtFone2Forne.setText(rs.getString(11));
				txtTipoProdutoForne.setText(rs.getString(12));
				txtIdProduto.setText(rs.getString(13));

			} else {
				// Mensagem se n�o existir um Fornecedor cadastrado
				JOptionPane.showMessageDialog(null, "Fornecedor n�o cadastrado");
				limpar();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para adicionar os Fornecedores */
	private void adicionarFornecedor() {
		String adicionaFornecedor = "insert into tb_fornecedor(idFornecedor,nomeForne,cnpjForne,emailForne,cepForne,cidadeForne,bairroForne,ruaForne,complementoEndForne,fone1Forne,fone2Forne,tipoProdutoForne,idProduto) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			pst = conex.prepareStatement(adicionaFornecedor);

			pst.setString(1, txtIdFornecedor.getText());
			pst.setString(2, txtNomeForne.getText());
			pst.setString(3, txtCnpjForne.getText());
			pst.setString(4, txtEmailForne.getText());
			pst.setString(5, txtCepForne.getText());
			pst.setString(6, txtCidadeForne.getText());
			pst.setString(7, txtBairroForne.getText());
			pst.setString(8, txtRuaForne.getText());
			pst.setString(9, txtComplementoEndForne.getText());
			pst.setString(10, txtFone1Forne.getText());
			pst.setString(11, txtFone2Forne.getText());
			pst.setString(12, txtTipoProdutoForne.getText());
			pst.setString(13, txtIdProduto.getText());

			// Valida��o dos campos obrigat�rios
			if ((txtNomeForne.getText().isEmpty()) || (txtCnpjForne.getText().isEmpty())) {
				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");

			} else {
				// CRIANDO UMA V�RIAV�L PARA EXECUTAR A QUERY E EXIBIR UMA MENSAGEM AO USU�RIO
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Fornecedor cadastrado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao cadastrar Fornecedor");
				}

			}

		} catch (Exception e) {

			System.out.println(e);
		}
	}

	/* M�todo para alterar usu�rios */

	private void alterarFornecedor() {
		String alterarForn = "update tb_fornecedor set nomeForne = ?,cnpjForne = ?,emailForne = ?,cepForne = ?,cidadeForne = ?,bairroForne = ?,ruaForne = ?,complementoEndForne = ?,fone1Forne = ?,fone2Forne = ?,tipoProdutoForne = ?,idProduto = ? where idFornecedor = ? ";
		try {
			pst = conex.prepareStatement(alterarForn);

			pst.setString(1, txtNomeForne.getText());
			pst.setString(2, txtCnpjForne.getText());
			pst.setString(3, txtEmailForne.getText());
			pst.setString(4, txtCepForne.getText());
			pst.setString(5, txtCidadeForne.getText());
			pst.setString(6, txtBairroForne.getText());
			pst.setString(7, txtRuaForne.getText());
			pst.setString(8, txtComplementoEndForne.getText());
			pst.setString(9, txtFone1Forne.getText());
			pst.setString(10, txtFone2Forne.getText());
			pst.setString(11, txtTipoProdutoForne.getText());
			pst.setString(12, txtIdProduto.getText());
			pst.setString(13, txtIdFornecedor.getText());

			if ((txtNomeForne.getText().isEmpty()) || (txtCnpjForne.getText().isEmpty())) {
				JOptionPane.showMessageDialog(null, "Preencha os campos obrigat�rios");

			} else {
				// CRIANDO UMA V�RIAV�L PARA EXECUTAR A QUERY E EXIBIR UMA MENSAGEM AO USU�RIO
				int adicionado = pst.executeUpdate();
				if (adicionado == 1) {
					JOptionPane.showMessageDialog(null, "Fornecedor alterado com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "Erro ao alterar Fornecedor");
				}

			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todos para remover um Fornecedor */

	private void removerFornecedor() {
		String removerForn = "delete from tb_fornecedor where idFornecedor = ?";
		try {
			pst = conex.prepareStatement(removerForn);
			pst.setString(1, txtIdFornecedor.getText());
			int confirma = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja remover este fornecedor?",
					"Aten��o", JOptionPane.YES_NO_OPTION);
			if (confirma == JOptionPane.YES_NO_OPTION) {
				int removido = pst.executeUpdate();
				if (removido == 1) {
					JOptionPane.showMessageDialog(null, "Fornecedor removido com sucesso");
					limpar();
				} else {
					JOptionPane.showMessageDialog(null, "N�o foi poss�vel remover fornecedor");
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	/* M�todo para limpar os campos */

	private void limpar() {
		txtIdFornecedor.setText(null);
		txtNomeForne.setText(null);
		txtCnpjForne.setText(null);
		txtEmailForne.setText(null);
		txtCepForne.setText(null);
		txtCidadeForne.setText(null);
		txtBairroForne.setText(null);
		txtRuaForne.setText(null);
		txtComplementoEndForne.setText(null);
		txtFone1Forne.setText(null);
		txtFone2Forne.setText(null);
		txtTipoProdutoForne.setText(null);
		txtIdProduto.setText(null);

	}

	private JPanel contentPane;
	private JTextField txtIdFornecedor;
	private JTextField txtNomeForne;
	private JTextField txtCnpjForne;
	private JTextField txtEmailForne;
	private JTextField txtCepForne;
	private JTextField txtCidadeForne;
	private JTextField txtBairroForne;
	private JTextField txtRuaForne;
	private JTextField txtComplementoEndForne;
	private JTextField txtFone1Forne;
	private JTextField txtFone2Forne;
	private JTextField txtTipoProdutoForne;
	private JTextField txtIdProduto;
	private JTextField txtFuncPesquisaForne;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FornecedorComanda frame = new FornecedorComanda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FornecedorComanda() {
		setResizable(true);
		setIconifiable(true);
		setClosable(true);
		setTitle("Fornecedor");
		setBounds(0, 0, 974, 727);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblIdforne = new JLabel("ID FORNECEDOR");
		lblIdforne.setBounds(10, 11, 71, 14);
		contentPane.add(lblIdforne);

		JLabel lblCnpjforne = new JLabel("NOME");
		lblCnpjforne.setBounds(10, 36, 71, 14);
		contentPane.add(lblCnpjforne);

		JLabel lblNomeforne = new JLabel("CNPJ");
		lblNomeforne.setBounds(10, 61, 71, 14);
		contentPane.add(lblNomeforne);

		JLabel lblTipoprodutoforne = new JLabel("E-MAIL");
		lblTipoprodutoforne.setBounds(10, 90, 71, 14);
		contentPane.add(lblTipoprodutoforne);

		JLabel lblCepforne = new JLabel("CEP");
		lblCepforne.setBounds(10, 115, 71, 14);
		contentPane.add(lblCepforne);

		JLabel label_5 = new JLabel("* Campos obrigat\u00F3rio");
		label_5.setBounds(10, 140, 130, 14);
		contentPane.add(label_5);

		JLabel lblBairroforne = new JLabel("CIDADE");
		lblBairroforne.setBounds(261, 11, 87, 14);
		contentPane.add(lblBairroforne);

		JLabel lblRuaforne = new JLabel("BAIRRO");
		lblRuaforne.setBounds(261, 36, 87, 14);
		contentPane.add(lblRuaforne);

		JLabel lblComplementoforne = new JLabel("RUA");
		lblComplementoforne.setBounds(261, 61, 87, 14);
		contentPane.add(lblComplementoforne);

		JLabel lblCidadeforne = new JLabel("COMPLEMENTO");
		lblCidadeforne.setBounds(261, 86, 87, 14);
		contentPane.add(lblCidadeforne);

		JLabel lblFoneforne = new JLabel("FONE 1");
		lblFoneforne.setBounds(261, 115, 87, 14);
		contentPane.add(lblFoneforne);

		JLabel lblFoneforne_1 = new JLabel("FONE 2");
		lblFoneforne_1.setBounds(498, 11, 70, 14);
		contentPane.add(lblFoneforne_1);

		JLabel lblEmailforne = new JLabel("TIPO PRODUTO");
		lblEmailforne.setBounds(498, 36, 100, 14);
		contentPane.add(lblEmailforne);

		JLabel lblIdproduto = new JLabel("ID PRODUTO");
		lblIdproduto.setBounds(498, 61, 86, 14);
		contentPane.add(lblIdproduto);

		txtIdFornecedor = new JTextField();
		txtIdFornecedor.setColumns(10);
		txtIdFornecedor.setBounds(91, 5, 164, 20);
		contentPane.add(txtIdFornecedor);

		txtNomeForne = new JTextField();
		txtNomeForne.setColumns(10);
		txtNomeForne.setBounds(91, 30, 164, 20);
		contentPane.add(txtNomeForne);

		txtCnpjForne = new JTextField();
		txtCnpjForne.setColumns(10);
		txtCnpjForne.setBounds(91, 55, 164, 20);
		contentPane.add(txtCnpjForne);

		txtEmailForne = new JTextField();
		txtEmailForne.setColumns(10);
		txtEmailForne.setBounds(91, 80, 164, 20);
		contentPane.add(txtEmailForne);

		txtCepForne = new JTextField();
		txtCepForne.setColumns(10);
		txtCepForne.setBounds(91, 109, 164, 20);
		contentPane.add(txtCepForne);

		txtCidadeForne = new JTextField();
		txtCidadeForne.setColumns(10);
		txtCidadeForne.setBounds(358, 5, 130, 20);
		contentPane.add(txtCidadeForne);

		txtBairroForne = new JTextField();
		txtBairroForne.setColumns(10);
		txtBairroForne.setBounds(358, 30, 130, 20);
		contentPane.add(txtBairroForne);

		txtRuaForne = new JTextField();
		txtRuaForne.setColumns(10);
		txtRuaForne.setBounds(358, 55, 130, 20);
		contentPane.add(txtRuaForne);

		txtComplementoEndForne = new JTextField();
		txtComplementoEndForne.setColumns(10);
		txtComplementoEndForne.setBounds(358, 80, 130, 20);
		contentPane.add(txtComplementoEndForne);

		txtFone1Forne = new JTextField();
		txtFone1Forne.setColumns(10);
		txtFone1Forne.setBounds(358, 109, 130, 20);
		contentPane.add(txtFone1Forne);

		txtFone2Forne = new JTextField();
		txtFone2Forne.setColumns(10);
		txtFone2Forne.setBounds(594, 5, 130, 20);
		contentPane.add(txtFone2Forne);

		txtTipoProdutoForne = new JTextField();
		txtTipoProdutoForne.setColumns(10);
		txtTipoProdutoForne.setBounds(594, 30, 130, 20);
		contentPane.add(txtTipoProdutoForne);

		txtIdProduto = new JTextField();
		txtIdProduto.setColumns(10);
		txtIdProduto.setBounds(594, 55, 130, 20);
		contentPane.add(txtIdProduto);

		txtFuncPesquisaForne = new JTextField();
		txtFuncPesquisaForne.setColumns(10);
		txtFuncPesquisaForne.setBounds(295, 184, 183, 20);
		contentPane.add(txtFuncPesquisaForne);

		JButton btnPesquisar = new JButton("");
		btnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pesquisarFornecedor();
			}
		});
		btnPesquisar.setIcon(
				new ImageIcon(FornecedorComanda.class.getResource("/br/com/comandaRestaurante/icones/read.png")));
		btnPesquisar.setBounds(310, 402, 89, 82);
		contentPane.add(btnPesquisar);

		JButton btnAdicionar = new JButton("");
		btnAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				adicionarFornecedor();
			}
		});
		btnAdicionar.setIcon(
				new ImageIcon(FornecedorComanda.class.getResource("/br/com/comandaRestaurante/icones/create.png")));
		btnAdicionar.setBounds(172, 402, 89, 82);
		contentPane.add(btnAdicionar);

		JButton btnAlterar = new JButton("");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alterarFornecedor();
			}
		});
		btnAlterar.setIcon(
				new ImageIcon(FornecedorComanda.class.getResource("/br/com/comandaRestaurante/icones/update.png")));
		btnAlterar.setBounds(445, 402, 89, 82);
		contentPane.add(btnAlterar);

		JButton btnExcluir = new JButton("");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				removerFornecedor();
			}
		});
		btnExcluir.setIcon(
				new ImageIcon(FornecedorComanda.class.getResource("/br/com/comandaRestaurante/icones/delete.png")));
		btnExcluir.setBounds(575, 402, 89, 82);
		contentPane.add(btnExcluir);

		JLabel label_16 = new JLabel("");
		label_16.setIcon(
				new ImageIcon(FornecedorComanda.class.getResource("/br/com/comandaRestaurante/icones/pesquisar.png")));
		label_16.setBounds(488, 165, 46, 56);
		contentPane.add(label_16);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(91, 215, 714, 109);
		contentPane.add(scrollPane);

		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"", null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"ID", "NOME", "CNPJ", "E-MAIL", "CEP", "CIDADE", "BAIRRO", "RUA", "COMPLEMENTO", "FONE 1", "FONE 2", "TIPO PRODUTO", "ID PRODUTO"
			}
		));
		scrollPane.setViewportView(table);

		conex = ConexaoBancoDados.conect();
	}
}
