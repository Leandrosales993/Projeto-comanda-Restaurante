package br.com.comandaRestaurante.formularios;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JDesktopPane;
import java.awt.event.ActionListener;

import java.awt.event.ActionEvent;
import javax.swing.JMenuItem;

import br.com.comandaRestaurante.conex.ConexaoBancoDados;
import java.awt.Color;

public class ComandaPrincipalR extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ComandaPrincipalR frame = new ComandaPrincipalR();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ComandaPrincipalR() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		setType(Type.UTILITY);
		setBounds(100, 100, 1000, 800);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 794, 21);
		contentPane.add(menuBar);

		JMenu menu = new JMenu("Cadastro");
		menuBar.add(menu);

		JMenu menu_5 = new JMenu("Relat\u00F3rios");
		menuBar.add(menu_5);

		JMenu menu_6 = new JMenu("Pedidos");
		menu_5.add(menu_6);

		JMenu menu_7 = new JMenu("Ajuda");
		menuBar.add(menu_7);

		JMenu menu_8 = new JMenu("Manual");
		menu_7.add(menu_8);

		JMenu menu_9 = new JMenu("Sobre");
		menu_7.add(menu_9);

		JMenu menu_10 = new JMenu("Op\u00E7\u00F5es");
		menuBar.add(menu_10);

		JMenu menu_11 = new JMenu("Sair");
		menu_10.add(menu_11);

		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBackground(Color.LIGHT_GRAY);
		desktopPane.setBounds(10, 33, 974, 727);
		contentPane.add(desktopPane);

		// Menu -> usu�rio
		JMenuItem mntmFuncionario = new JMenuItem("Funcionario");
		mntmFuncionario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				FuncionarioComanda funcionario = new FuncionarioComanda();
				funcionario.setVisible(true);
				desktopPane.add(funcionario);
			}
		});
		menu.add(mntmFuncionario);

		// Menu -> Cliente
		JMenuItem mntmCliente = new JMenuItem("Cliente");
		mntmCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ClienteComanda cliente = new ClienteComanda();
				cliente.setVisible(true);
				desktopPane.add(cliente);
			}
		});
		menu.add(mntmCliente);

		// Menu -> Fornecedor
		JMenuItem mntmFornecedor = new JMenuItem("Fornecedor");
		mntmFornecedor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				FornecedorComanda fornecedor = new FornecedorComanda();
				fornecedor.setVisible(true);
				desktopPane.add(fornecedor);

			}
		});
		menu.add(mntmFornecedor);
		// Menu -> Produto
		JMenuItem mntmProduto_1 = new JMenuItem("Produto");
		mntmProduto_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProdutoComanda produto = new ProdutoComanda();
				produto.setVisible(true);
				desktopPane.add(produto);
			}
		});
		menu.add(mntmProduto_1);

		JMenu mnComanda = new JMenu("Comanda");
		menuBar.add(mnComanda);

		JMenuItem mntmComanda = new JMenuItem("Comanda");
		mntmComanda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ComandaPrincipal comanda = new ComandaPrincipal();
				comanda.setVisible(true);
				desktopPane.add(comanda);
			}
		});
		
		JMenuItem mntmPedido = new JMenuItem("Pedido");
		mntmPedido.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PedidoComanda pedido = new PedidoComanda();
				pedido.setVisible(true);
				desktopPane.add(pedido);
			}
		});
		mnComanda.add(mntmPedido);
		mnComanda.add(mntmComanda);

	}
}
