package br.com.comandaRestaurante.conex;

// Importa��o de biblioteca e recursos para trabalhar o sql no java
// Importando o mysql
import java.sql.*;

/**
 * 
 * @uthor Marcio Roberto
 */
public class ConexaoBancoDados {
	// M�todo est�tico com retorno
	// M�todo respons�vel por estabelecer a conex�o com BD

	public static Connection conect() {
		// A vari�vel conex � uma abrevia��o da palavra conex�o
		Connection conex = null;
		String driver = "com.mysql.jdbc.Driver";
		// ?useSSL= false quando n�o tenho criptografia
		// loca: localhost ou 127.0.0.1
		// ip: ip do servidor de banco de dados
		// web: link do servidor (nuvens)
		// Armazenando informa��es referente ao BD
		String url = "jdbc:mysql://192.168.15.201:3306/comanda?useSSL=false";
		String user = "roberto";
		String password = "MR123@Senac";
        // Estabelecendo a conex�o com BD 
		try {
			// Caso d� tudo certo
			Class.forName(driver);// uso do driver
			conex = DriverManager.getConnection(url, user, password);
			return conex;
		} catch (Exception e) {
			// Caso d� alguma coisa errada, informe o erro
			System.out.println(e);
			return null;
		}
	}

}
